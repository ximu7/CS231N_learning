# -*- coding: utf-8 -*-

import streamlit as st
from Eload_clustering.Eload_clustering import Eload_easyclustering,read_data
import numpy as np
import pandas as pd


if __name__ == '__main__':
    # 读入样本数据
    @st.cache
    def load_data():
        data = read_data('test.txt')
        return data
    st.title("负荷聚类")
    # 选择合适的输入量
    algr_type = st.sidebar.selectbox(
        "Which kind of algorithm do you want to use?",
        ["KMeans","Birch","DBSCAN","SpectralClustering","MeanShift","Fuzzy_cmeans"]
    )

    k_ = st.sidebar.slider(
        "which K?",1,10
    )
    st.header('用电负荷数据')
    data = load_data()
    # 展示数据
    st.dataframe(data)

    # 进行聚类计算并将结果压缩成pd.DataFrame展示
    if st.button('点击开始抽样'):
        y_pre, dicts = Eload_easyclustering(algr_type,data,k_)
        k = list(dicts.keys())
        v = list(dicts.values())
        df = pd.DataFrame(list(zip(k, v)), columns=['行数', '类别'])
        st.header('负荷结果')
        classify_df = df.drop(columns='行数')
        st.dataframe(classify_df)

        y_pre = {'label':y_pre - min(y_pre)}
        st.header('负荷标签')
        y_pre_df = pd.DataFrame(y_pre)
        st.dataframe(y_pre)
