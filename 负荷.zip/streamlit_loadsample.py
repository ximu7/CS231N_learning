# -*- coding: utf-8 -*-

import streamlit as st
from load_sample.lhs_sample import data_sample, read_data
import numpy as np
import pandas as pd

if __name__ == '__main__':
    # 读取样本数据
    @st.cache
    def load_data():
        data = read_data('test.txt')
        return data
    st.title("负荷抽样")
    # 选择合适的输入量
    algr_type = st.sidebar.selectbox(
        "Which kind of algorithm do you want to use?",
        ["random", "lhs", "halton", "sobol"]
    )

    batch = st.sidebar.slider(
        "How much sample?",1,15
    )
    st.header('用电负荷数据')
    data = load_data()

    # 展示数据
    st.dataframe(data)

    # 进行抽样，并且展示
    if st.button('点击开始抽样'):
        X_sample = data_sample(algr_type, batch, data)
        st.header('负荷抽样结果')
        y_pre_df = pd.DataFrame(X_sample)
        st.dataframe(y_pre_df)
