# 开发说明
## 服务器存储位置
`/home/zyw/RDS_py`
## 新加和改动的各文件作用（截止20200305）
+ applied_algo
  + Eload_clustering
    + `__init__.py`：负荷聚类模块的对外接口
    + `Eload_clustering.py`：负荷聚类的{"KMeans"，"Birch"，"DBSCAN"，"SpectralClustering","MeanShift","Fuzzy_cmeans"}模型。`sklearn`和`skfuzzy`库原有的模块函数，需要针对目标数据进行调参
  + risk_assessment
    + `__init__.py`：增加风险评估模块的对外接口
    + `lhs_sample.py`:负荷抽样的{"random"，"lhs"，"halton"，"sobol"}模型，主要利用了pipy开发完成的库pysampling实现
+ interfaces
  + `flask_loadcluster.py`：负荷聚类对外接口，主要用于web api应用
  + `flask_loadsample.py`：负荷样本抽样对外接口，主要用于web api应用
  + `streamlit_loadckuster.py`: 负荷样本聚类的streamlit展示接口，主要用于前后端解耦
  + `streamlit_loadckuster.py`: 负荷样本抽样的streamlit展示接口，主要用于前后端解耦
+ dataset
  + `test.txt`：嘉兴日负荷数据截取样本，15*24
## 开发情况
增加和修改过的文件都在**服务器环境**中测试过编写的样例，应该都能跑通。  
`doc.md`为对应API说明文档