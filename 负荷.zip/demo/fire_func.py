"""
展示命令行模块使用方法
"""
import fire
from basic_func import cal_func

if __name__ == '__main__':
    fire.Fire(cal_func)