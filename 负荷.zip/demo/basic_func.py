# -*- coding: utf-8 -*-
"""
@File  : basic_func.py
@Time  :
@Author: LWH
@Func  : 基础加法
"""
class Calculator():
    """
    加减乘除
    """
    def __init__(self):
        self.result = None
    def add(self, a, b):
        return a + b
    def div(self, a, b):
        return a/b
    def minus(self, a, b):
        return a-b
    def mul(self, a, b):
        return a*b
    def cal(self, a, b, method="add"):
        if method == "add":
            return self.add(a, b)
        elif method == "div":
            return self.div(a, b)
        elif method == "minus":
            return self.minus(a, b)
        elif method == "mul":
            return self.mul(a, b)
        return None


def cal_func(a, b, mode="add"):
    """
    封装，计算函数（接口）
    :param a:
    :param b:
    :return:
    """
    calculator = Calculator()
    return calculator.cal(a, b, mode)


if __name__ == '__main__':
    calculator = Calculator()
    print(calculator.add(1,2), calculator.div(1,2))