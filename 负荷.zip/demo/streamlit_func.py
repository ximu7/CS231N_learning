"""
streamlit示例
"""
import streamlit as st
from basic_func import cal_func

if __name__ == '__main__':
    '''
    # 计算器的app测试页面1
    '''
    a = st.number_input(label="参数1")
    b = st.number_input(label="参数2")
    mode = None

    sel = st.radio(
        '操作符选择',
        ['加', '减', '乘', '除']
    )
    if sel == '加':
        mode = "add"
    elif sel == '减':
        mode = "minus"
    elif sel == '乘':
        mode = "mul"
    else:
        mode = "div"

    if st.button('点击开始计算'):
        res = cal_func(a, b, mode)
        st.write('正确答案为：', round(res, 5))