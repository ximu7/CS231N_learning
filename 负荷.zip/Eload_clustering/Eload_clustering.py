# -*- coding: utf-8 -*-
import numpy as np
from sklearn.cluster import KMeans
from sklearn.cluster import Birch 
from sklearn.cluster import DBSCAN
from sklearn.cluster import SpectralClustering 
from sklearn.cluster import MeanShift
from sklearn.metrics import calinski_harabaz_score,calinski_harabasz_score
from skfuzzy.cluster import cmeans




#读取训练集的数据
def read_data(dir):
    dataset=[]
    with open(dir,'r') as f:
        for line in f:
            if line == '\n':
                continue
            dataset.append(list(map(float,line.split('\t'))))
        f.close()
    # print(np.array(dataset).shape)
    # print(dataset)
    print(dataset)
    return np.array(dataset)

#对数据X和对应标签进行采样，采样方法可定"KMeans"，"Birch"，"DBSCAN"，"SpectralClustering","MeanShift","Fuzzy_cmeans"
def Eload_easyclustering(algrithm,X,k = None):
    """ 
        采用多种聚类方法对N*C的数据进行聚类，N表示数据个数，C表示数据维度，最后输出(N,)的标签矩阵。
        algorithm："KMeans"，"Birch"，"DBSCAN"，"SpectralClustering","MeanShift","Fuzzy_cmeans"
        X: training data
        k: n_clusters numbers
        
        Outputs: 
        y_pre: y clusters predict label
    """
    if k == 0:
        k = None
    if algrithm == "KMeans":
        y_pre = KMeans(n_clusters=k).fit_predict(X)
    elif algrithm == "Birch":
        y_pre = Birch(n_clusters=k).fit_predict(X)
    elif algrithm == "DBSCAN":
        y_pre = DBSCAN(eps=0.5, min_samples=5).fit_predict(X)
    elif algrithm == "SpectralClustering":
        y_pre = SpectralClustering(n_clusters=k).fit_predict(X)
    elif algrithm == "MeanShift":
        y_pre = SpectralClustering(n_clusters=k).fit_predict(X)
    elif algrithm == "Fuzzy_cmeans":
        cntr, u, u0, d, jm, p, fpc = cmeans(X.T, k, 2, error=0.005, maxiter=1000, init=None)
        y_pre = np.argmax(u, axis=0)

    # 使用Calinski-Harabasz Index评估的聚类分数: 分数越高，表示聚类的效果越好
    # print(calinski_harabaz_score(X, y_pre))
    y_pre = y_pre - np.min(y_pre)
    if k == None :
        k = np.max(y_pre)
    dicts={}
    for i in range(k):
        idx = np.where(y_pre == i)
        dicts[i]=(idx[0].tolist())
    y_pre=list(y_pre.astype(float))

    return y_pre,dicts

    

    


if __name__ == "__main__":
    X = read_data('test.txt')
    print(X)
    y_pre, dicts = Eload_easyclustering("KMeans",X, 3)
    print(y_pre)
    # print(calinski_harabasz_score(X, y_pre))
    
    
    