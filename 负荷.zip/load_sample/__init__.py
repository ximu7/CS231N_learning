# -*- coding: utf-8 -*-

from load_sample.lhs_sample import data_sample