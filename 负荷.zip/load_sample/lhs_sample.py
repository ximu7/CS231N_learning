# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from pysampling.sample import sample
import numpy as np

#读取训练集的数据
def read_data(dir):
    dataset=[]
    with open(dir,'r') as f:
        for line in f:
            if line == '\n':
                continue
            dataset.append(list(map(float,line.split('\t'))))
        f.close()
    # print(np.array(dataset).shape)
    return np.array(dataset)

#对数据X和对应标签进行采样，采样方法
def data_sample(algorithm, batch, X, y = None):
    """ 
        algorithm："random"，"lhs"，"halton"，"sobol"
        batch：N for samples number
        X: training data
        y: label data ps: if it exists
        
        Outputs:
        X_sample : samples of X training data 
        y : samples of y training label
    """
    idX = sample(algorithm, batch, 1)*X.shape[0]
    idX = np.floor(idX).astype(np.int).reshape(-1)

    X_sample = X[idX]
    if y != None:
        y_sample = y[idX]
        return X_sample,y_sample
    else:
        return X_sample
    
  

    


if __name__ == "__main__":
    X = read_data('test.txt')
    X_sample,y_sample = data_sample("lhs",50, X)
    print(X_sample)